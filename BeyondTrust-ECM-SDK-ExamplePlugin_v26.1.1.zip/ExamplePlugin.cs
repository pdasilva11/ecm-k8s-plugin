using BeyondTrust.Integration.ECM.SDK.Model;
using BeyondTrust.Integration.ECM.SDK.Plugin;
using BeyondTrust.Integration.ECM.SDK.Util;
using Microsoft.Extensions.Options;
using System.Diagnostics;
using System.Reflection;

namespace MyCompany.Integrations.ExamplePlugin
{
    public class ExamplePlugin : IECMPlugin
    {
        private static readonly ILogger _logger = ECMLoggerFactory.CreateLogger<ExamplePlugin>();

        public ExamplePlugin(IOptions<ExamplePluginConfig> config)
        {
            // Possible tasks to handle when the service is instantiated:
            //  - validate configuration
            //  - initialize any sort of API client or other types that will be required for servicing requests
            //  - pre-load any information that may be required for servicing requests (files, API / product version info, etc.)
        }

        #region  General Properties and Methods <=============================================================================
        /// <summary>
        /// The proper name of the plugin (ex: CompanyName ProductName Plugin)
        /// </summary>
        public string Name => "BeyondTrust Example Plugin";

        /// <summary>
        /// An optional description of the plugin / integration
        /// </summary>
        public string Description => "Doesn't actually do anything, but makes a good starting point for a new plugin";

        /// <summary>
        /// The version of the plugin which should be updated with each release and can aid in debugging / support
        /// </summary>
        public string Version => FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion;
        //public string Version => "1.0.0";
        // ^^^ You can use an explicit value here or leave this to dynamically pull the version from the metadata on the assembly

        /// /// <summary>
        /// <para>Constructs a <see cref="PluginCapabilities"/> which indicate which, if any, extended capabilities a plugin supports</para>
        /// <para>NOTE: If a plugin reports that it does NOT support a given capability, the SRA site will not route requests of that type to the ECM/plugin instance</para>
        /// </summary>
        /// <returns></returns>
        public virtual async Task<ActionResult<PluginCapabilities>> GetPluginCapabilitiesAsync()
        {
            var capabilities = new PluginCapabilities
            {
                SupportsCredentialsUsed = false,
                SupportsEndpointSearch = false,
                SupportsHealthCheck = false,
                SupportsSessionComplete = false,
                SupportsSessionStarted = false,
                SupportsStartSession = false
            };

            // the default behavior is that the plugin does not support any of the newer capabilities
            return await Task.FromResult(new ActionResult<PluginCapabilities> { ResultValue = capabilities, IsSuccess = true });
        }

        /// <summary>
        /// Action handler for the Health Check action which, if supported, allows an SRA site to periodically confirm that a
        /// connected ECM/plugin instance is in a healthy state and ready to process requests
        /// </summary>
        /// <returns></returns>
        public virtual async Task<ActionResult<PluginHealthStatus>> PerformHealthCheckAsync()
        {
            // Since we're reporting via GetPluginCapabilities that we do NOT support health checks, no implementation is needed ...
            //
            // HOWEVER, for most plugins this should be implemented. The SRA site will check on health status once per minute so any
            // implementation should be a relatively inexpensive operation, but also one that would give the best oportunity to identify
            // any issues which may prevent the plugin from successfully handling requests for credentials, endpoints, etc.
            //
            // This operation could be as simple as verifying that the plugin has configuration and any required fields are populated, but
            // it could also be smarter and attempt some sort of communication with the password vaulting system. This would cover multiple
            // checks at once including: verifying that configuration is present, verifying network connectivity, and verifying the basic
            // components of the configuration such as auth details are correct.

            throw new NotImplementedException($"The {Name} definition must implement {nameof(PerformHealthCheckAsync)} as defined by {nameof(IECMPlugin)}");
        }
        #endregion

        #region Credential Action Methods <=============================================================================
        /// <summary>
        /// Retrieves a list of credentials available to the user and applicable to the endpoint
        /// </summary>
        /// <param name="session">Contains data about the session (including user and system)</param>
        /// <returns>A list of credentials available to the user and applicable to the endpoint</returns>
        public async Task<ActionResult<IList<CredentialSummary>>> FindCredentialsForSessionAsync(SRASession session)
        {
            // At this point the user has chosen a Jump Item in the console and attempted to initiate a session to the target system.
            // The plugin should retrieve a list of credentials that are either queried or filtered based on the supplied
            // information about the user and system to which the user is connecting.
            // NOTE: While the operation is async, the SRA site will only wait for a certain period of time (20 seconds by default)
            //      for the list to be returned before it proceeds without presenting any creds for selection.
            
            throw new NotImplementedException($"The {Name} definition must implement {nameof(FindCredentialsForSessionAsync)} as defined by {nameof(ICredentialActions)}");
        }

        /// <summary>
        /// Retrieves a specific credential to be used to authenticate to the endpoint
        /// </summary>
        /// <param name="session">Contains data about the session (including user and system)</param>
        /// <param name="credentialId">Unique ID of a specific credential</param>
        /// <returns>A credential package containing the components of selected credential necessary for authentication</returns>
        public async Task<ActionResult<CredentialPackage>> GetCredentialForInjectionAsync(SRASession session, string credentialId)
        {
            // The user has been presented with a list of credentials (supplied by FindCredentialsForSessionAsync above) and has
            // selected one from the list. The plugin should use the information supplied about the session as well as the ID of
            // the selected credential to attempt to retrieve / check-out that credential and return it for injection into the session.
            // NOTE: As above, it is important to note that while the operation is async, the same timeout applies.

            throw new NotImplementedException($"The {Name} definition must implement {nameof(GetCredentialForInjectionAsync)} as defined by {nameof(ICredentialActions)}");
        }

        /// <summary>
        /// Marks the credential as 'used' or ready to be released when the session ends
        ///   NOTE: It is not necessary to override this method.  If the password store has no concept of
        ///   releasing a credential, checking it in, or anything else that would need to be done at this
        ///   point in the workflow, then nothing needs to be done and this can be omitted.  It is included
        ///   here simply to highlight it's presence and purpose.
        /// </summary>
        /// <param name="session">Contains data about the session (including user and system)</param>
        /// <param name="credentialId">Unique ID of a specific credential</param>
        /// <param name="sessionEndedTimestamp">Unix timestamp representing when the session ended</param>
        /// <returns></returns>
        public async Task<ActionResult> ReleaseCredentialFromSessionAsync(SRASession session, string credentialId, long sessionEndedTimestamp)
        {
            // And at this point the session has ended and the SRA site is notifying the ECM / plugin in case any clean-up or check-in actions
            // need to be performed in order to release the credential so other users can access it.
            // NOTE: Any responses that return an ActionResult indicating failure will result in the SRA site retrying the request until it is met
            //      with a successful response or the request eventually times out of the queue. If it is unlikely that a given error scenario will
            //      ever result in success, then it is best to return a successful response here but adequately log anything that went wrong.

            throw new NotImplementedException($"The {Name} definition must implement {nameof(ReleaseCredentialFromSessionAsync)} as defined by {nameof(ICredentialActions)}");
        }
        #endregion

        #region Endpoint Action Methods <=============================================================================

        /// <summary>
        /// Retrieves a list of endpoints available to the user and applicable to the search criteria and types 
        /// </summary>
        /// <param name="session">Contains data about the session (including user and system)</param>
        /// <param name="endpointSearchTypes">Types of endpoints to construct and return</param>
        /// <param name="searchCriteria">Criteria for finding matching endpoints</param>
        /// <param name="mostRecentlyUsedCount">Number of endpoints to return for a most-recently-used endpoints list</param>
        /// <returns></returns>
        public async Task<ActionResult<IReadOnlyList<EndpointPackage>>> FindAvailableEndpointsAsync(SRASession session, IReadOnlyList<EndpointPackageType> endpointSearchTypes, string searchCriteria, int? mostRecentlyUsedCount)
        {
            // If the SRA site has the feature enabled and the plugin reports that it supports endpoint search (via GetPluginCapabilities), then 
            // users can search for External Jump Items. Such a search will result in a call to this method with the expectation being that the
            // plugin will find and return a list of systems / endpoints that can be presented as ad hoc Jump Items to which the user can open sessions.
            // NOTE: Since these are ad hoc items as opposed to persistent items with installed clients, the connections must go through a Jumpoint. Either
            //      the external system from which the endpoint information is pulled or the plugin itself must supply a value in PushAgentNetworkId to
            //      identify the appropriate Jumpoint for each endpoint returned.

            throw new NotImplementedException($"The {Name} definition must implement {nameof(FindAvailableEndpointsAsync)} as defined by {nameof(IEndpointActions)}");
        }
        #endregion

        #region Session Action Methods <=============================================================================
        /// <summary>
        /// Signals the external system of a request to start a managed / tracked session 
        /// </summary>
        /// <param name="session">Contains data about the session (including user and system)</param>
        /// <param name="credentialId">The ID of the credential which will be used to initiate the session</param>
        /// <returns></returns>
        public async Task<ActionResult<StartSessionDetails>> StartSessionAsync(SRASession session, string credentialId)
        {
            // For External Jump Items (provided via FindAvailableEndpointsAsync), if the external system has a mechanism for
            // managing / tracking sessions initiated to these endpoints and using managed credentials, this method is used to
            // notify the system that the user has requested that a session be initiated. 
            // NOTE: This is NOT a common use case and will remain not implemented for the majority of plugins

            throw new NotImplementedException($"The {Name} definition must implement {nameof(StartSessionAsync)} as defined by {nameof(ISessionActions)}");
        }

        /// <summary>
        /// Signals the external system that a managed / tracked session has started
        /// </summary>
        /// <param name="session">Contains data about the session (including user and system)</param>
        /// <param name="historyUrl">(Optional) URL for tracked session in external system</param>
        /// <param name="historyUrlExpirySeconds">(Optional) Expiry for history URL of tracked session in external system</param>
        /// <returns></returns>
        public async Task<ActionResult> SessionStartedAsync(SRASession session, string? historyUrl = null, int? historyUrlExpirySeconds = null)
        {
            // For External Jump Items (provided via FindAvailableEndpointsAsync), if the external system has a mechanism for
            // managing / tracking sessions initiated to these endpoints and using managed credentials, this method is used to
            // notify the system that such a session has started. 
            // NOTE: This is NOT a common use case and will remain not implemented for the majority of plugins

            throw new NotImplementedException($"The {Name} definition must implement {nameof(SessionStartedAsync)} as defined by {nameof(ISessionActions)}");
        }

        /// <summary>
        /// Signals the external system that a managed / tracked session has been completed
        /// </summary>
        /// <param name="session">Contains data about the session (including user and system)</param>
        /// <returns></returns>
        public async Task<ActionResult> SessionCompleteAsync(SRASession session)
        {
            // For External Jump Items (provided via FindAvailableEndpointsAsync), if the external system has a mechanism for
            // managing / tracking sessions initiated to these endpoints and using managed credentials, this method is used to
            // notify the system that such a session has completed. 
            // NOTE: This is NOT a common use case and will remain not implemented for the majority of plugins

            throw new NotImplementedException($"The {Name} definition must implement {nameof(SessionCompleteAsync)} as defined by {nameof(ISessionActions)}");
        }
        #endregion
    }
}
